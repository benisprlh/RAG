# Notebooks

Folder ini berisi notebook demonstrasi, eksperimen, dan contoh penggunaan pipeline RAG gabungan.

- Gunakan untuk eksplorasi, prototyping, dan dokumentasi interaktif. 