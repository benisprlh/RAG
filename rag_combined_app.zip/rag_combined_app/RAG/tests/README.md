# Tests

Folder ini berisi unit test, evaluasi pipeline, dan skrip pengujian untuk aplikasi RAG gabungan.

- Pastikan pipeline berjalan dengan benar dan hasil evaluasi dapat direproduksi. 